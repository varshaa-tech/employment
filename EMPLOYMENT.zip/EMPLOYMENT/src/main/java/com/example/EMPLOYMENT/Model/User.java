package com.example.EMPLOYMENT.Model;

import jakarta.persistence.*;

@Entity
@Table(name = "users") // Table name aligned with naming conventions
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String bookName;

    @Column(nullable = false)
    private String issueDate;

    @Column(nullable = false)
    private String returnDate;

    @Column(nullable = false)
    private String hashedPassword; // Store hashed passwords securely

    // Default Constructor
    public User() {
    }

    // Parameterized Constructor
    public User(String name, String bookName, String issueDate, String returnDate, String hashedPassword) {
        this.name = name;
        this.bookName = bookName;
        this.issueDate = issueDate;
        this.returnDate = returnDate;
        this.hashedPassword = hashedPassword;
    }

    // Getters and Setters
    // Follow camelCase naming for methods

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBook_name() {
        return bookName;
    }

    public void setBook_name(String bookName) {
        this.bookName = bookName;
    }

    public String getIssue_date() {
        return issueDate;
    }

    public void setIssue_date(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getReturn_date() {
        return returnDate;
    }

    public void setReturn_date(String returnDate) {
        this.returnDate = returnDate;
    }

    public String getPassword() {
        return hashedPassword;
    }

    public void setPassword(String hashedPassword) {
        this.hashedPassword = hashedPassword; // 🛑 Plain text password store karna insecure hai!
    }

}
