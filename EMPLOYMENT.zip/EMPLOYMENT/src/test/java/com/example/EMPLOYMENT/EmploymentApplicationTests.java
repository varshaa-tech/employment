package com.example.EMPLOYMENT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmploymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
